This is the new static folder with images.
