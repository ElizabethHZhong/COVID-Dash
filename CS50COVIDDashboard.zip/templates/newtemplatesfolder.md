This is the new templates folder with the html files.
